package com.example.raf_backend.entities;

public enum UserType {
    CONTENT_CREATOR,
    ADMIN
}
