<template>

</template>

<script>
export default {
  name: "EditArticle",
  props: {
    title: {type:String, default: ''},
    cateogry: {type:String, default: ''},
    text: {type:String, default: ''},
    author: {type:String, default: ''},
    tags: {type:String, default: ''},

  }
}
</script>

<style scoped>

</style>